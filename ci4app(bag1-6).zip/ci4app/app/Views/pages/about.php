<div class="container">
    <div class="row">
        <div class="col">
            <h1>About Me</h1>
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vel error qui quaerat consequuntur! Officia, debitis iure illum eveniet itaque, reprehenderit asperiores ducimus veniam modi ipsa dolorem enim consequatur reiciendis alias!</p>

        </div>
    </div>
</div>